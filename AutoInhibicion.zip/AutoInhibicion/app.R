#
# This is a Shiny web application. You can run the application by clicking
# the 'Run App' button above.
#
# Find out more about building applications with Shiny here:
#
#    http://shiny.rstudio.com/
#

library(shiny)
library(deSolve)
library(ggplot2)

# Define UI for application that draws a histogram
ui <- fluidPage(

    # Application title
    titlePanel("Auto Inhibición"),

    # Sidebar with a slider input for number of bins 
    sidebarLayout(
        sidebarPanel(
            sliderInput("n",
                        "Escoge un valor de n",
                        min = 1,
                        max = 4,
                        value = 1),
            sliderInput("beta",
                        "Escoge un valor de beta",
                        min = 1,
                        max = 10,
                        value = 5),
            sliderInput("k",
                        "Escoge un valor de k",
                        min = 1,
                        max = 10,
                        value = 0.5),
            sliderInput("alfa",
                        "Escoge un valor de alfa",
                        min = 1,
                        max = 10,
                        value = 1)
        ),

        # Show a plot of the generated distribution
        mainPanel(
           plotOutput("Solution")
        )
    )
)

# Define server logic required to draw a histogram
server <- function(input, output) {

    output$Solution <- renderPlot({
        # generate bins based on input$bins from ui.R
        #x    <- faithful[, 2]
        #bins <- seq(min(x), max(x), length.out = input$bins + 1)
        auto_inh <- function(t, state, parameters) {
          with(as.list(c(state, parameters)), { 
            # The list of equations
            dX <- ((beta*(k)^n)/((k^n)+(x^n)))-alpha*x
            list(dX)
          })
        }
        # Paramaters values
        parameters <- c(k=input$k, alpha=input$alfa, 
                        n=input$n, beta=input$beta)
        
        # Initial conditions
        state <- c(x=0)
        
        # The time lapse we'll be using
        times <- seq(0, 10, by = 0.01)
        
        # we make the differential equation "ode"
        out <- ode(y = state, times = times, 
                   func = auto_inh, parms = parameters)
        
        out<-as.data.frame(out)
        # we graph
        #plot(out,col="blue")
        #abline(h=(input$beta/input$alfa),color="red")
        
          ggplot(data = out, aes(y =x, x = time)) +
            geom_line(color = "olivedrab", size = 1) +
            ggtitle("Concentración de X") +
            theme_bw() + 
            ylab("X") 
            #geom_hline(yintercept = input$beta/input$alfa)
        
    
        # draw the histogram with the specified number of bins
        #hist(x, breaks = bins, col = 'darkgray', border = 'white')
    })
}

# Run the application 
shinyApp(ui = ui, server = server)
